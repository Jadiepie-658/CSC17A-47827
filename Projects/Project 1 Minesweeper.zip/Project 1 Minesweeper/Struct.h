/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Struct.h
 * Author: Jade Braun
 *
 * Created on October 20, 2019, 1:53 PM
 */

#ifndef STRUCT_H
#define STRUCT_H

//structures for how many mines there will be
struct Beginner {
    int mineN;
};

struct Inter {
    int min;
};

struct Hard {
    int bomb;
};

#endif /* STRUCT_H */

